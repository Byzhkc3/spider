#coding=utf-8
# 导入查询手机属性接口
from necessary.get_phone_attr import getPhoneAttr

# 导入联通查询接口
from china_unicom.china_unicom import  chinaUnicomAPI

# 导入移动查询接口
from china_mobile.china_mobile_gd import getNoteCode, loginSys


