from flask import Flask, render_template
# from flask.ext.moment import Moment
from china_unicom.china_unicom_search import chinaUnicomAPI

app = Flask(__name__)
# moment = Moment(app)

@app.route('/')
def index():
    return render_template('index.html')


@app.route('/check')
def check():
    return render_template('check.html')


@app.route('/get_data/<number>/<password>')
def get_data(number, password):
    r = chinaUnicomAPI(number, password)
    return render_template('output.html', user=r['t_china_unicom_uesr'][0])

if __name__ == '__main__':
    app.run(debug=True)
