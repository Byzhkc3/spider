from config_operate import ConfigOperate
from share_func import userAgent, basicRequest,\
    xpathText, binaryzationImage, saveImage,  getIp